/*
 * Ext JS Library 2.0.2
 * Copyright(c) 2006-2008, Ext JS, LLC.
 * licensing@extjs.com
 * 
 * http://extjs.com/license
 */


Ext.MessageBox=function(){var _1,_2,_3,_4;var _5,_6,_7,_8,_9,pp,_b,_c;var _d,_e,_f,_10="";var _11=function(_12){_1.hide();Ext.callback(_2.fn,_2.scope||window,[_12,_e.dom.value],1);};var _13=function(){if(_2&&_2.cls){_1.el.removeClass(_2.cls);}
_9.reset();};var _14=function(d,k,e){if(_2&&_2.closable!==false){_1.hide();}
if(e){e.stopEvent();}};var _18=function(b){var _1a=0;if(!b){_d["ok"].hide();_d["cancel"].hide();_d["yes"].hide();_d["no"].hide();return _1a;}
_1.footer.dom.style.display="";for(var k in _d){if(typeof _d[k]!="function"){if(b[k]){_d[k].show();_d[k].setText(typeof b[k]=="string"?b[k]:Ext.MessageBox.buttonText[k]);_1a+=_d[k].el.getWidth()+15;}else{_d[k].hide();}}}
return _1a;};return{getDialog:function(_1c){if(!_1){_1=new Ext.Window({autoCreate:true,title:_1c,resizable:false,constrain:true,constrainHeader:true,minimizable:false,maximizable:false,stateful:false,modal:true,shim:true,buttonAlign:"center",width:400,height:100,minHeight:80,plain:true,footer:true,closable:true,close:function(){if(_2&&_2.buttons&&_2.buttons.no&&!_2.buttons.cancel){_11("no");}else{_11("cancel");}}});_d={};var bt=this.buttonText;_d["ok"]=_1.addButton(bt["ok"],_11.createCallback("ok"));_d["yes"]=_1.addButton(bt["yes"],_11.createCallback("yes"));_d["no"]=_1.addButton(bt["no"],_11.createCallback("no"));_d["cancel"]=_1.addButton(bt["cancel"],_11.createCallback("cancel"));_d["ok"].hideMode=_d["yes"].hideMode=_d["no"].hideMode=_d["cancel"].hideMode="offsets";_1.render(document.body);_1.getEl().addClass("x-window-dlg");_3=_1.mask;_5=_1.body.createChild({html:"<div class=\"ext-mb-icon\"></div><div class=\"ext-mb-content\"><span class=\"ext-mb-text\"></span><br /><input type=\"text\" class=\"ext-mb-input\" /><textarea class=\"ext-mb-textarea\"></textarea></div>"});_b=Ext.get(_5.dom.firstChild);var _1e=_5.dom.childNodes[1];_6=Ext.get(_1e.firstChild);_7=Ext.get(_1e.childNodes[2]);_7.enableDisplayMode();_7.addKeyListener([10,13],function(){if(_1.isVisible()&&_2&&_2.buttons){if(_2.buttons.ok){_11("ok");}else{if(_2.buttons.yes){_11("yes");}}}});_8=Ext.get(_1e.childNodes[3]);_8.enableDisplayMode();_9=new Ext.ProgressBar({renderTo:_5});_5.createChild({cls:"x-clear"});}
return _1;},updateText:function(_1f){if(!_1.isVisible()&&!_2.width){_1.setSize(this.maxWidth,100);}
_6.update(_1f||"&#160;");var iw=_10!=""?(_b.getWidth()+_b.getMargins("lr")):0;var mw=_6.getWidth()+_6.getMargins("lr");var fw=_1.getFrameWidth("lr");var bw=_1.body.getFrameWidth("lr");if(Ext.isIE&&iw>0){iw+=3;}
var w=Math.max(Math.min(_2.width||iw+mw+fw+bw,this.maxWidth),Math.max(_2.minWidth||this.minWidth,_f||0));if(_2.prompt===true){_e.setWidth(w-iw-fw-bw);}
if(_2.progress===true||_2.wait===true){_9.setSize(w-iw-fw-bw);}
_1.setSize(w,"auto").center();return this;},updateProgress:function(_25,_26,msg){_9.updateProgress(_25,_26);if(msg){this.updateText(msg);}
return this;},isVisible:function(){return _1&&_1.isVisible();},hide:function(){if(this.isVisible()){_1.hide();_13();}
return this;},show:function(_28){if(this.isVisible()){this.hide();}
_2=_28;var d=this.getDialog(_2.title||"&#160;");d.setTitle(_2.title||"&#160;");var _2a=(_2.closable!==false&&_2.progress!==true&&_2.wait!==true);d.tools.close.setDisplayed(_2a);_e=_7;_2.prompt=_2.prompt||(_2.multiline?true:false);if(_2.prompt){if(_2.multiline){_7.hide();_8.show();_8.setHeight(typeof _2.multiline=="number"?_2.multiline:this.defaultTextHeight);_e=_8;}else{_7.show();_8.hide();}}else{_7.hide();_8.hide();}
_e.dom.value=_2.value||"";if(_2.prompt){d.focusEl=_e;}else{var bs=_2.buttons;var db=null;if(bs&&bs.ok){db=_d["ok"];}else{if(bs&&bs.yes){db=_d["yes"];}}
if(db){d.focusEl=db;}}
this.setIcon(_2.icon);_f=_18(_2.buttons);_9.setVisible(_2.progress===true||_2.wait===true);this.updateProgress(0,_2.progressText);this.updateText(_2.msg);if(_2.cls){d.el.addClass(_2.cls);}
d.proxyDrag=_2.proxyDrag===true;d.modal=_2.modal!==false;d.mask=_2.modal!==false?_3:false;if(!d.isVisible()){document.body.appendChild(_1.el.dom);d.setAnimateTarget(_2.animEl);d.show(_2.animEl);}
d.on("show",function(){if(_2a===true){d.keyMap.enable();}else{d.keyMap.disable();}},this,{single:true});if(_2.wait===true){_9.wait(_2.waitConfig);}
return this;},setIcon:function(_2d){if(_2d&&_2d!=""){_b.removeClass("x-hidden");_b.replaceClass(_10,_2d);_10=_2d;}else{_b.replaceClass(_10,"x-hidden");_10="";}
return this;},progress:function(_2e,msg,_30){this.show({title:_2e,msg:msg,buttons:false,progress:true,closable:false,minWidth:this.minProgressWidth,progressText:_30});return this;},wait:function(msg,_32,_33){this.show({title:_32,msg:msg,buttons:false,closable:false,wait:true,modal:true,minWidth:this.minProgressWidth,waitConfig:_33});return this;},alert:function(_34,msg,fn,_37){this.show({title:_34,msg:msg,buttons:this.OK,fn:fn,scope:_37});return this;},confirm:function(_38,msg,fn,_3b){this.show({title:_38,msg:msg,buttons:this.YESNO,fn:fn,scope:_3b,icon:this.QUESTION});return this;},prompt:function(_3c,msg,fn,_3f,_40){this.show({title:_3c,msg:msg,buttons:this.OKCANCEL,fn:fn,minWidth:250,scope:_3f,prompt:true,multiline:_40});return this;},OK:{ok:true},CANCEL:{cancel:true},OKCANCEL:{ok:true,cancel:true},YESNO:{yes:true,no:true},YESNOCANCEL:{yes:true,no:true,cancel:true},INFO:"ext-mb-info",WARNING:"ext-mb-warning",QUESTION:"ext-mb-question",ERROR:"ext-mb-error",defaultTextHeight:75,maxWidth:600,minWidth:100,minProgressWidth:250,buttonText:{ok:"OK",cancel:"Cancel",yes:"Yes",no:"No"}};}();Ext.Msg=Ext.MessageBox;